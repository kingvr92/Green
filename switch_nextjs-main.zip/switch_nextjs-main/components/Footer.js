export const FooterComponent = () => {
    return (
        <>
            <div className="">
                <footer className="page-footer font-small blue pt-4 text-light">
                    <div className="footer-copyright text-center py-3">© 2022-2023 Free-Source, Inc. All rights reserved, develop by LeKZanGx .
                    </div>
                </footer>
            </div>
        </>
    );
};